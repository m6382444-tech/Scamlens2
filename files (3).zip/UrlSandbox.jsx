import React, { useState, useEffect } from 'react';
import { 
  Globe, ShieldAlert, AlertTriangle, ArrowRight, ExternalLink, 
  CheckCircle, Lock, Unlock, Server, ShieldCheck, Terminal, AlertOctagon, RefreshCw 
} from 'lucide-react';
import { analyzeUrlThreat } from '../services/urlThreatService';

const SAMPLE_URLS = [
  { label: "Electricity Shortener", url: "https://bit.ly/power-pay-bill" },
  { label: "SBI KYC Phishing", url: "https://sbi-kyc-verify-portal.top" },
  { label: "India Post ₹25 Trap", url: "http://indiapost-track-update.cc/track" },
  { label: "e-Challan APK Dropper", url: "http://echallan-parivahan-gov.buzz/echallan.apk" },
  { label: "Official SBI (Safe)", url: "https://onlinesbi.sbi" }
];

export default function UrlSandbox({ initialUrl }) {
  const [targetUrl, setTargetUrl] = useState(initialUrl || 'https://bit.ly/power-pay-bill');
  const [loading, setLoading] = useState(false);
  const [threatResult, setThreatResult] = useState(null);

  useEffect(() => {
    if (initialUrl) {
      setTargetUrl(initialUrl);
      runInspection(initialUrl);
    } else {
      runInspection('https://bit.ly/power-pay-bill');
    }
  }, [initialUrl]);

  const runInspection = async (urlToTest) => {
    const url = urlToTest || targetUrl;
    if (!url) return;
    setLoading(true);
    try {
      const data = await analyzeUrlThreat(url);
      setThreatResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              URL Sandbox & Unshortener
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Safely extracts embedded links, follows redirect shorteners without executing scripts, and evaluates threat intelligence.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
            Threat Intel: Safe Browsing + Heuristics
          </span>
        </div>
      </div>

      {/* URL Input Bar */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && runInspection()}
            placeholder="Paste suspicious URL (e.g. bit.ly/..., .top, .buzz, .apk)..."
            className="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <button
            onClick={() => runInspection()}
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 font-bold text-sm text-white flex items-center justify-center space-x-2 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Unmasking...</span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-4 h-4" />
                <span>Safely Inspect URL</span>
              </>
            )}
          </button>
        </div>

        {/* Quick sample chips */}
        <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
          <span className="text-slate-400 font-medium">Test Samples:</span>
          {SAMPLE_URLS.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setTargetUrl(sample.url);
                runInspection(sample.url);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono transition-colors"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Inspection Results */}
      {threatResult && (
        <div className="space-y-6 animate-in fade-in">
          
          {/* Verdict Banner */}
          <div className={`p-5 rounded-2xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
            threatResult.riskScore >= 70
              ? 'bg-red-950/40 border-red-500/50 text-red-200'
              : threatResult.riskScore >= 40
              ? 'bg-amber-950/40 border-amber-500/50 text-amber-200'
              : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
          }`}>
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg ${
                threatResult.riskScore >= 70
                  ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              }`}>
                {threatResult.riskScore >= 70 ? '!' : '✓'}
              </div>
              <div>
                <span className="text-xs uppercase font-extrabold tracking-wider opacity-80">
                  URL Threat Verdict
                </span>
                <h3 className="text-xl font-extrabold text-white">
                  {threatResult.safetyVerdict}
                </h3>
              </div>
            </div>

            <div className="flex items-center space-x-6">
              <div>
                <span className="text-xs text-slate-400 block">Threat Score</span>
                <span className={`text-2xl font-black font-mono ${
                  threatResult.riskScore >= 70 ? 'text-red-400' : 'text-emerald-400'
                }`}>
                  {threatResult.riskScore}/100
                </span>
              </div>
              <div className="hidden sm:block pl-6 border-l border-slate-700">
                <span className="text-xs text-slate-400 block">Protocol</span>
                <span className="text-sm font-mono font-semibold text-slate-200 flex items-center space-x-1">
                  {threatResult.protocol === 'https:' ? (
                    <><Lock className="w-3.5 h-3.5 text-emerald-400" /><span>HTTPS</span></>
                  ) : (
                    <><Unlock className="w-3.5 h-3.5 text-rose-400" /><span>HTTP (Insecure)</span></>
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* Redirect Unshortening Trail */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span>URL Redirect Chain & Unshortened Target</span>
            </h4>

            {threatResult.isShortener && threatResult.unshortenedDestination ? (
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center space-x-2 text-xs text-slate-400">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">Original:</span>
                    <span className="font-mono text-amber-300 truncate">{threatResult.url}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-xs">
                    <ArrowRight className="w-4 h-4 text-rose-400 shrink-0" />
                    <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-500/30 font-bold uppercase text-[10px]">
                      True Hidden Destination:
                    </span>
                    <span className="font-mono text-white font-bold break-all">
                      {threatResult.unshortenedDestination}
                    </span>
                  </div>
                </div>

                {/* Hops timeline */}
                {threatResult.redirectHops && threatResult.redirectHops.length > 0 && (
                  <div className="space-y-2 text-xs">
                    <span className="text-slate-400 uppercase tracking-wider text-[10px] font-bold">
                      Redirect Inspection Trail:
                    </span>
                    {threatResult.redirectHops.map((hop, i) => (
                      <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/60 font-mono">
                        <span className="text-slate-300 truncate max-w-[70%]">{hop.url}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          hop.status >= 300 && hop.status < 400 ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-700 text-slate-200'
                        }`}>
                          HTTP {hop.status} ({hop.reason || 'Hop'})
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-sm text-slate-300">
                <span className="text-xs text-slate-400 block mb-1">Direct Target URL:</span>
                <span className="break-all text-white font-semibold">{threatResult.url}</span>
              </div>
            )}
          </div>

          {/* Two-Column: Red Flags List + Sandbox Visual Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Left: Specific Red Flags */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>Detected Technical Red Flags ({threatResult.redFlags.length})</span>
              </h4>

              {threatResult.redFlags.length === 0 ? (
                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-xs text-emerald-300 flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>No obvious malicious domain attributes detected. Still verify if unexpected.</span>
                </div>
              ) : (
                <div className="space-y-3">
                  {threatResult.redFlags.map((flag, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-rose-300">{flag.type}</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                          {flag.severity}
                        </span>
                      </div>
                      <p className="text-slate-400">{flag.detail}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Host Heuristics metadata */}
              <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 space-y-2">
                <div className="flex justify-between">
                  <span>SSL Certificate:</span>
                  <span className="text-slate-200 font-mono">{threatResult.sandboxDetails.sslStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span>Server Infrastructure:</span>
                  <span className="text-slate-200 font-mono">{threatResult.sandboxDetails.serverLocation}</span>
                </div>
                <div className="flex justify-between">
                  <span>Domain Age Estimate:</span>
                  <span className="text-rose-400 font-mono">{threatResult.sandboxDetails.domainAgeEstimate}</span>
                </div>
              </div>
            </div>

            {/* Right: Simulated Safe Sandbox Browser Preview */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>Sanitized Sandbox Render</span>
                </h4>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Isolated Preview
                </span>
              </div>

              {/* Browser Window Chrome */}
              <div className="rounded-xl border border-slate-700 bg-slate-950 overflow-hidden shadow-inner">
                {/* Browser Tab Bar */}
                <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center space-x-2 text-xs">
                  <div className="flex space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  </div>
                  <div className="flex-1 ml-2 px-3 py-1 rounded bg-slate-950 text-slate-400 font-mono text-[11px] truncate border border-slate-800 flex items-center space-x-1">
                    <Lock className="w-3 h-3 text-rose-500 shrink-0" />
                    <span>{threatResult.hostname}</span>
                  </div>
                </div>

                {/* Phishing Page Simulation Wireframe */}
                <div className="p-5 space-y-3 relative">
                  {threatResult.riskScore >= 70 && (
                    <div className="absolute inset-0 bg-red-950/80 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center p-6 text-center space-y-3">
                      <AlertOctagon className="w-12 h-12 text-red-500 animate-bounce" />
                      <div>
                        <h5 className="text-base font-extrabold text-white">
                          DECEPTIVE SITE BLOCKED BY SCAMLENS
                        </h5>
                        <p className="text-xs text-red-200 mt-1 max-w-sm">
                          This landing page is engineered to harvest internet banking passwords, card CVVs, or download Trojan APKs.
                        </p>
                      </div>
                      <div className="text-[11px] text-slate-300 font-mono bg-slate-950/90 px-3 py-1.5 rounded-lg border border-red-500/40">
                        Never submit OTP or install files from this host.
                      </div>
                    </div>
                  )}

                  {/* Wireframe background elements */}
                  <div className="h-4 w-32 bg-slate-800 rounded"></div>
                  <div className="h-3 w-48 bg-slate-800/60 rounded"></div>
                  <div className="h-8 w-full bg-slate-900 rounded border border-slate-800"></div>
                  <div className="h-8 w-full bg-slate-900 rounded border border-slate-800"></div>
                  <div className="h-9 w-28 bg-rose-600/60 rounded"></div>
                </div>
              </div>

              {/* Safety Guidance */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
                <p className="font-semibold text-white">Safe Browsing Rule:</p>
                <p className="text-slate-400">
                  Government portals end strictly in <strong>.gov.in</strong> or <strong>.nic.in</strong>. State Bank of India uses <strong>.sbi</strong>. Unofficial domains ending in .top, .buzz, or .cc should never be trusted.
                </p>
              </div>
            </div>

          </div>

        </div>
      )}
    </div>
  );
}
