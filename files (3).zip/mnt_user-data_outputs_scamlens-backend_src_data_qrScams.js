// Pre-loaded realistic QR code scam scenarios for Indian and global users

export const QR_SCAM_DEMOS = [
  {
    id: "olx-upi-scam",
    title: "OLX 'Scan to Receive Money' Scam",
    category: "UPI Reverse Collect Fraud",
    urgencyLevel: "Critical",
    description: "Scammer poses as a buyer on OLX/Marketplace and sends a QR code claiming: 'Scan this QR code and enter your PIN to receive the advance payment'.",
    qrPayload: "upi://pay?pa=olxpayee77@ybl&pn=RahulBuyer&am=18500.00&cu=INR&tn=AdvancePaymentForSofa",
    payloadType: "UPI Intent",
    threatScore: 99,
    threatLevel: "CRITICAL FRAUD TRAP",
    scamTrick: "Reverse Collect Request Trap",
    plainEnglishWarning: "CRITICAL WARNING: Scanning this QR code and entering your UPI PIN will DEDUCT ₹18,500 from your bank account! You NEVER need to enter your UPI PIN to receive money. UPI PIN is strictly used to TRANSFER money out.",
    whyScammersUseIt: "Exploits confusion about how QR codes work. Victims believe that scanning a QR code can credit money to their account.",
    safeAction: "Never scan a QR code sent by a buyer. If anyone asks you to scan a code or enter your PIN to 'receive payment', immediately cancel and block them."
  },
  {
    id: "electricity-qr",
    title: "Electricity Bill Cutoff Phishing QR",
    category: "Utility Phishing",
    urgencyLevel: "Critical",
    description: "Fake paper bill or WhatsApp notice with a QR code directing the victim to a spoofed electricity payment gateway.",
    qrPayload: "https://mahavitaran-bill-verify.top/pay.php?consumer=9823101928",
    payloadType: "Phishing URL",
    threatScore: 95,
    threatLevel: "CRITICAL PHISHING LINK",
    scamTrick: "Weaponized Domain QR Code",
    plainEnglishWarning: "The QR code points to 'mahavitaran-bill-verify.top'. This is a counterfeit domain using a suspicious '.top' extension to harvest net banking passwords and debit card CVVs.",
    whyScammersUseIt: "Bypasses text-based SMS spam filters by embedding the phishing link inside a visual QR barcode.",
    safeAction: "Pay utility dues only through the official Discom mobile application or official website ending in '.in' or '.gov.in'."
  },
  {
    id: "echallan-apk-qr",
    title: "Traffic Police e-Challan APK Dropper QR",
    category: "Malware / APK Dropper",
    urgencyLevel: "Critical",
    description: "Fake traffic violation notice sticker pasted on car windshield with a QR code claiming 'Scan to pay pending court challan'.",
    qrPayload: "http://echallan-parivahan-court.buzz/challan.apk",
    payloadType: "Malicious APK Download",
    threatScore: 98,
    threatLevel: "MALICIOUS ANDROID TROJAN",
    scamTrick: "Physical Drive-By Malicious APK Dropper",
    plainEnglishWarning: "This QR code triggers a direct download of 'challan.apk' onto your smartphone. This APK is an SMS-stealing Spyware that forwards your incoming OTPs to scammers.",
    whyScammersUseIt: "Victims panic seeing a court warrant notice on their vehicle and scan the QR code without realizing it installs unauthorized software.",
    safeAction: "Never install APK files downloaded from QR codes. Check vehicle challans directly on echallan.parivahan.gov.in."
  },
  {
    id: "kbc-lottery-qr",
    title: "KBC ₹25 Lakh Lottery Claim QR",
    category: "Lottery Advance Fee",
    urgencyLevel: "High",
    description: "WhatsApp certificate image containing a QR code to 'Verify winning ticket and claim prize draft'.",
    qrPayload: "https://kbc-jio-lottery-claim.cc/cheque.php?id=KBC8921",
    payloadType: "Phishing URL",
    threatScore: 92,
    threatLevel: "ADVANCE FEE LOTTERY SCAM",
    scamTrick: "Visual Credential & Tax Trap",
    plainEnglishWarning: "Points to an unofficial '.cc' domain asking for ₹12,500 'processing tax' before releasing a non-existent lottery draft.",
    whyScammersUseIt: "Adds an illusion of high-tech legitimacy to an otherwise transparent advance-fee lottery scam.",
    safeAction: "Ignore lottery claims for contests you never entered. Real lotteries do not ask for advance taxes via QR codes."
  },
  {
    id: "safe-merchant-qr",
    title: "Verified Legitimate Merchant QR (Safe Demo)",
    category: "Genuine Payment QR",
    urgencyLevel: "Safe",
    description: "Standard verified merchant QR code found at retail stores, restaurants, or official e-commerce checkouts.",
    qrPayload: "upi://pay?pa=swiggy@icici&pn=SwiggyVerifiedMerchant&cu=INR",
    payloadType: "Verified UPI Merchant",
    threatScore: 5,
    threatLevel: "VERIFIED SAFE MERCHANT",
    scamTrick: "None (Legitimate Payment Flow)",
    plainEnglishWarning: "This is a legitimate verified merchant UPI handle registered with ICICI Bank. It contains NO forced debit amounts or reverse collect requests.",
    whyScammersUseIt: "N/A - Genuine merchant payment QR.",
    safeAction: "Safe to proceed if you intend to pay this merchant for goods or services."
  }
];
