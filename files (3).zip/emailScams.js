export const EMAIL_SCAM_DEMOS = [
  {
    id: "hdfc-kyc-email",
    title: "HDFC NetBanking KYC Suspended",
    category: "Banking Phishing Email",
    claimedSender: "HDFC Bank Security Desk",
    fromEmail: "security-alerts@hdfc-verification-desk.top",
    legitimateDomain: "hdfcbank.com",
    subject: "URGENT: Your NetBanking Access Has Been Suspended - Complete Mandatory KYC",
    body: "Dear Customer,\n\nWe noticed suspicious unauthorized activity on your HDFC Bank account. In accordance with RBI guidelines, your internet banking access has been temporarily blocked.\n\nTo prevent permanent account deactivation and penalties, you must update your PAN, Aadhaar and Debit Card details within 24 hours at http://hdfc-kyc-verify-portal.top/login.\n\nFailure to verify will result in immediate freeze of all debit cards and outward transactions.\n\nSincerely,\nHDFC Bank Security Cell",
    attachment: "KYC_Update_Form.html",
    threatScore: 98,
    threatLevel: "CRITICAL PHISHING EMAIL",
    threatFlags: [
      { type: "Domain Impersonation", detail: "Sent from 'hdfc-verification-desk.top' instead of official 'hdfcbank.com'." },
      { type: "Weaponized Urgency", detail: "Demands panic verification 'within 24 hours' or face account deactivation." },
      { type: "Malicious Attachment", detail: "Contains '.html' file engineered to execute an offline credential-harvesting form." },
      { type: "Insecure Phishing URL", detail: "Directs victim to unverified '.top' lookalike domain." }
    ],
    plainWarning: "Banks NEVER send emails asking customers to click links to update KYC, PAN, or debit card PINs. Real banks instruct you to visit the branch or use the official mobile app.",
    safeAction: "Mark as Phishing / Spam and delete immediately. Never open .html attachments."
  },
  {
    id: "tax-refund-email",
    title: "Income Tax Department Refund Approved",
    category: "Tax Refund Phishing",
    claimedSender: "Income Tax Department CPC",
    fromEmail: "refund-cell@incometax-gov-online.buzz",
    legitimateDomain: "incometax.gov.in",
    subject: "Refund Order: ₹42,850 Approved - Confirm Bank Details Immediately",
    body: "Dear Taxpayer,\n\nIncome Tax Department has approved a tax refund of ₹42,850 for Assessment Year 2026-27. However, the automated transfer to your bank account failed due to incomplete account details.\n\nPlease immediately click http://incometax-refund-claim.buzz/verify to confirm your bank account and enter your NetBanking password to receive immediate direct credit.\n\nIf not confirmed within 48 hours, this refund order will be canceled and forfeited to the Treasury.\n\nIncome Tax Department, New Delhi",
    attachment: "Tax_Refund_Form.apk",
    threatScore: 99,
    threatLevel: "MALWARE & CREDENTIAL FRAUD",
    threatFlags: [
      { type: "Government Spoofing", detail: "Sent from '.buzz' domain. Genuine tax emails strictly end in '.gov.in'." },
      { type: "APK Malware Attachment", detail: "Attachment 'Tax_Refund_Form.apk' is a malicious Trojan that intercepts banking SMS OTPs." },
      { type: "Greed & Urgency Trap", detail: "Lures victim with ₹42,850 refund while imposing a 48h expiration threat." }
    ],
    plainWarning: "The Income Tax Department never distributes refund forms as Android .apk files and never sends emails asking for NetBanking passwords.",
    safeAction: "Check your real refund status strictly on the official e-Filing portal: eportal.incometax.gov.in."
  },
  {
    id: "customs-parcel-email",
    title: "Airport Customs Seizure & CBI Threat",
    category: "Extortion / Customs Scam",
    claimedSender: "Mumbai Airport Customs Commissioner",
    fromEmail: "clearance-office@mumbai-customs-cargo.top",
    legitimateDomain: "cbic.gov.in",
    subject: "CONFISCATION NOTICE: Parcel #IN-982019 Seized at Customs Terminal",
    body: "URGENT OFFICIAL NOTICE:\n\nConsignment #IN-982019 addressed to you has been confiscated at Mumbai International Airport Customs Cargo Terminal. The parcel was found to contain undeclared foreign currency (British Pounds) and gold jewelry.\n\nYou are directed to pay Customs Clearance Duty and Fine of ₹32,000 within 12 hours via bank transfer.\n\nFailure to pay will result in the immediate issuance of a non-bailable arrest warrant by the Central Bureau of Investigation (CBI) under the Customs Act 1962 and Money Laundering Prevention Act.\n\nCustoms Enforcement Directorate, Mumbai",
    attachment: "CBI_Arrest_Warrant.scr",
    threatScore: 96,
    threatLevel: "CRITICAL EXTORTION EMAIL",
    threatFlags: [
      { type: "Authority Extortion Threat", detail: "Threatens CBI arrest warrant within 12 hours unless ₹32,000 is wired." },
      { type: "Deceptive Sender Address", detail: "Uses fake '.top' domain mimicking Mumbai Customs." },
      { type: "Executable Payload", detail: "Attachment ends in '.scr' (Windows screen-saver executable trojan)." }
    ],
    plainWarning: "Customs officers never demand clearance fees via personal bank transfer or threaten arrest warrants via email within 12 hours.",
    safeAction: "Report this sender immediately to the 1930 Cybercrime Helpline. Do not pay any fee."
  }
];

export const IMAGE_SCAM_DEMOS = [
  {
    id: "kbc-cheque-image",
    title: "KBC ₹25 Lakh WhatsApp Lottery Cheque",
    category: "Lottery Cheque Image",
    summary: "Fake certificate with Amitabh Bachchan's photo and Reliance Jio logo claiming mobile number won ₹25 Lakhs.",
    simulatedOcrText: "CONGRATULATIONS! KBC JIO LUCKY DRAW 2026. Your mobile number has won Cash Prize of ₹25,00,000 (Twenty Five Lakh Rupees). Lottery Number: KBC-8921. To claim prize money, contact KBC Manager Rana Pratap Singh on WhatsApp: +92-345-6789012. You must pay refundable processing tax of ₹12,500 within 24 hours.",
    extractedUrls: [],
    extractedPhones: ["+92 345 6789012"],
    imageTheme: "gold-certificate"
  },
  {
    id: "electricity-notice-image",
    title: "Electricity Disconnection WhatsApp Notice",
    category: "Utility Cutoff Notice Image",
    summary: "Letterhead graphic warning of night power disconnection at 9:30 PM with officer phone number.",
    simulatedOcrText: "URGENT ELECTRICITY NOTICE: Dear Consumer, your power supply will be disconnected tonight at 9:30 PM from electricity substation because previous month bill was not updated. Immediately contact Electricity Officer Sharma at 9876543210 or update bill at bit.ly/power-pay-bill to avoid disconnection. - Discom Dept.",
    extractedUrls: ["https://bit.ly/power-pay-bill"],
    extractedPhones: ["9876543210"],
    imageTheme: "warning-letter"
  },
  {
    id: "cbi-digital-arrest-image",
    title: "CBI / Police Digital Arrest Letterhead",
    category: "Digital Arrest Order Image",
    summary: "Fake stamped police letterhead claiming 14 illegal SIM cards and narcotics trafficking.",
    simulatedOcrText: "CENTRAL BUREAU OF INVESTIGATION - NEW DELHI CYBER WING. NOTICE OF DIGITAL ARREST. FIR #492/2026. 14 illegal SIM cards tied to Aadhaar. You are placed under immediate DIGITAL ARREST. Connect to interrogation link at cbi-cyber-investigation.online/court within 60 minutes or warrant of arrest will be executed.",
    extractedUrls: ["https://cbi-cyber-investigation.online/court"],
    extractedPhones: [],
    imageTheme: "police-letterhead"
  }
];
