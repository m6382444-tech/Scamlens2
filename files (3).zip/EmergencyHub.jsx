import React, { useState } from 'react';
import { 
  PhoneCall, ShieldAlert, ExternalLink, Copy, Check, AlertOctagon, 
  Clock, Share2, FileText, Send, HeartHandshake, ShieldCheck 
} from 'lucide-react';

export default function EmergencyHub({ currentAnalysis, rawText, senderNumber }) {
  const [copiedHelpline, setCopiedHelpline] = useState(false);
  const [copiedComplaint, setCopiedComplaint] = useState(false);
  const [copiedFamilyCard, setCopiedFamilyCard] = useState(false);

  const handleCopyHelpline = () => {
    navigator.clipboard.writeText("1930");
    setCopiedHelpline(true);
    setTimeout(() => setCopiedHelpline(false), 2000);
  };

  // Build formal legal cybercrime complaint draft
  const now = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
  const complaintDraft = `
OFFICIAL CYBERCRIME INCIDENT DRAFT
Reporting to: National Cyber Crime Reporting Portal (cybercrime.gov.in) & Chakshu
Incident Report Date: ${now} (IST)

1. INCIDENT OVERVIEW:
   Category: Phishing / Financial Extortion / Identity Impersonation Attempt
   Applicable Legal Provisions:
   - Section 66D, IT Act 2000 (Cheating by personation using computer resource)
   - Section 66C, IT Act 2000 (Identity theft & credential harvesting)
   - Section 420, Indian Penal Code (Cheating and dishonestly inducing delivery of property)

2. SUSPECT DETAILS:
   Suspect Phone / Sender Header: ${senderNumber || '+91 98765 43210 (Spoofed Sender)'}
   Suspect Phishing URLs: ${currentAnalysis?.detectedUrls?.length ? currentAnalysis.detectedUrls.join(', ') : 'Attached in evidence text'}

3. EVIDENCE TRANSCRIPT:
   "${rawText || 'Dear Consumer, your electricity power will be disconnected tonight at 9:30 PM... Please immediately contact electricity officer at 9876543210'}"

4. INVESTIGATION FINDINGS (SCAMLENS):
   - Threat Level: ${currentAnalysis?.threatLevel || 'CRITICAL PHISHING SCAM'} (Score: ${currentAnalysis?.threatScore || 95}%)
   - Detected Triggers: ${currentAnalysis?.highlights?.map(h => `[${h.label}] "${h.text}"`).join('; ') || 'Artificial urgency, spoofed authority claims, micro-fee trap'}

5. RELIEF SOUGHT:
   - Immediate deactivation of suspect SIM/VOIP route via DoT Chakshu.
   - Domain takedown of phishing link.
   - Freeze associated mule accounts / UPI handles under I4C protocol.
`.trim();

  // Family WhatsApp warning snippet
  const familyCardDraft = `
🚨 *SCAM ALERT FOR FAMILY & FRIENDS* 🚨
Please be careful! A new scam message is circulating on SMS & WhatsApp:

⚠️ *Scam Message:*
"${(rawText || 'Electricity bill unpaid / KYC account suspended in 2 hours / India Post ₹25 fee').slice(0, 150)}..."

🛑 *HOW TO STAY SAFE:*
1. *Banks & Electricity boards NEVER* disconnect service at night or demand urgent updates via bit.ly links!
2. *NEVER share OTP* or pay small ₹10 / ₹25 token fees on unknown links.
3. *Police NEVER conduct "Digital Arrest" on video calls!*
4. If anyone calls asking for bank details or remote app install (AnyDesk), *HANG UP IMMEDIATELY*.

If you suspect financial fraud, call the National Cyber Helpline *1930* immediately!
(Checked & verified safe via ScamLens)
`.trim();

  const handleCopyComplaint = () => {
    navigator.clipboard.writeText(complaintDraft);
    setCopiedComplaint(true);
    setTimeout(() => setCopiedComplaint(false), 2500);
  };

  const handleCopyFamilyCard = () => {
    navigator.clipboard.writeText(familyCardDraft);
    setCopiedFamilyCard(true);
    setTimeout(() => setCopiedFamilyCard(false), 2500);
  };

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-red-950/60 via-slate-900 to-slate-900 border border-red-500/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              Emergency Action Hub & Indian Cybercrime Portals
            </h2>
            <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">
              Official Indian Channels
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Quick-action reporting for immediate fund freezing (Golden Hour) and telecom SIM deactivation through government authorities.
          </p>
        </div>

        <a
          href="tel:1930"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 font-bold text-white shadow-xl shadow-red-950/60 flex items-center space-x-2 transition-all transform hover:scale-105"
        >
          <PhoneCall className="w-5 h-5 animate-bounce" />
          <span>Call 1930 Helpline Now</span>
        </a>
      </div>

      {/* Grid of Indian Authority Quick Action Portals */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* 1. 1930 Golden Hour Helpline */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-red-500/50 shadow-xl shadow-red-950/20 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">
                Financial Fraud Emergency
              </span>
              <Clock className="w-4 h-4 text-rose-400 animate-spin" />
            </div>
            <h3 className="text-xl font-extrabold text-white flex items-center space-x-2">
              <span>National Helpline</span>
              <span className="text-red-500 text-2xl">1930</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Managed by Indian Cyber Crime Coordination Centre (I4C), Ministry of Home Affairs. 
            </p>
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200">
              <strong className="block font-bold text-white mb-0.5">The "Golden Hour" Protocol:</strong>
              If money was debited from your account within the last 2 hours, dialing 1930 enables real-time coordination with banks to freeze the fraudster's beneficiary wallet/account before withdrawal!
            </div>
          </div>

          <div className="pt-2 flex gap-2">
            <a
              href="tel:1930"
              className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Direct Dial 1930</span>
            </a>
            <button
              onClick={handleCopyHelpline}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold"
              title="Copy 1930"
            >
              {copiedHelpline ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* 2. Chakshu Portal (DoT Sanchar Saathi) */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-amber-500/40 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Department of Telecom (DoT)
              </span>
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            </div>
            <h3 className="text-xl font-extrabold text-white">
              Chakshu Portal
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Official Sanchar Saathi citizen facility for reporting suspected fraudulent communications before financial loss occurs.
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
              <strong className="block font-semibold text-slate-200">What Chakshu Handles:</strong>
              <p>• Suspicious phone numbers & spoofed WhatsApp calls</p>
              <p>• Fake SMS sender headers (e.g. AD-SBIPAY)</p>
              <p>• Electricity & India Post phishing SMS</p>
            </div>
          </div>

          <a
            href="https://sancharsaathi.gov.in/sfc/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Chakshu Reporting Portal</span>
          </a>
        </div>

        {/* 3. National Cyber Crime Portal (cybercrime.gov.in) */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-indigo-500/40 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                Legal FIR & Investigation
              </span>
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
            </div>
            <h3 className="text-xl font-extrabold text-white">
              cybercrime.gov.in
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              National portal to file formal criminal complaints and cyber police complaints against cyber syndicates.
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
              <strong className="block font-semibold text-slate-200">Legal Provisions Invoked:</strong>
              <p>• IT Act Sec 66D (Cheating by personation)</p>
              <p>• IT Act Sec 66C (Identity & KYC theft)</p>
              <p>• IPC Sec 420 (Cheating and fraud)</p>
            </div>
          </div>

          <a
            href="https://cybercrime.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>File Complaint at cybercrime.gov.in</span>
          </a>
        </div>

      </div>

      {/* Two Pre-Filled Generators: 1-Click Formal Legal Complaint + Family WhatsApp Warning */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Generator 1: Official Formal Complaint Text */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-indigo-400" />
              <h4 className="text-base font-bold text-white">
                1-Click Pre-Filled Complaint Draft
              </h4>
            </div>
            <button
              onClick={handleCopyComplaint}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              {copiedComplaint ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Formal Draft</span>
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-slate-400">
            Ready to paste directly into the complaint description box at <strong>cybercrime.gov.in</strong> or the Chakshu portal.
          </p>

          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap max-h-64 overflow-y-auto">
            {complaintDraft}
          </pre>
        </div>

        {/* Generator 2: Family WhatsApp Alert Card */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <HeartHandshake className="w-5 h-5 text-emerald-400" />
              <h4 className="text-base font-bold text-white">
                WhatsApp Family Group Warning Card
              </h4>
            </div>
            <button
              onClick={handleCopyFamilyCard}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              {copiedFamilyCard ? (
                <>
                  <Check className="w-3.5 h-3.5 text-white" />
                  <span>Copied Alert!</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Copy for WhatsApp</span>
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-slate-400">
            A friendly, plain-language warning formatted with WhatsApp bold styling to forward to parents and family group chats to protect them.
          </p>

          <pre className="p-4 rounded-xl bg-emerald-950/15 border border-emerald-500/30 font-sans text-xs text-emerald-200 leading-relaxed whitespace-pre-wrap max-h-64 overflow-y-auto">
            {familyCardDraft}
          </pre>
        </div>

      </div>
    </div>
  );
}
