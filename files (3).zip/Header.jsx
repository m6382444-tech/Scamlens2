import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  ShieldAlert, PhoneCall, Smartphone, Monitor, ExternalLink, Zap, 
  QrCode, Camera, Mail, BookOpen, AlertTriangle, Download, X, Wifi, Check, Copy, Globe, MessageSquare 
} from 'lucide-react';
import QRCode from 'qrcode';

export default function Header({ 
  activeTab, 
  setActiveTab, 
  deviceFrameMode, 
  setDeviceFrameMode 
}) {
  const [mobileModalOpen, setMobileModalOpen] = useState(false);
  const [mobileQrUrl, setMobileQrUrl] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedPublicUrl, setCopiedPublicUrl] = useState(false);

  // URLs for phone access
  const publicWebUrl = "https://earning-increasing-tmp-trek.trycloudflare.com";
  const phoneNetworkUrl = "http://172.20.10.2:3001";

  useEffect(() => {
    // Generate QR code for public web link (works on any network)
    QRCode.toDataURL(publicWebUrl, {
      width: 240,
      margin: 1,
      color: { dark: '#ffffff', light: '#020617' }
    }).then(url => setMobileQrUrl(url)).catch(err => console.error(err));
  }, []);

  const handleCopyPublicUrl = () => {
    navigator.clipboard.writeText(publicWebUrl);
    setCopiedPublicUrl(true);
    setTimeout(() => setCopiedPublicUrl(false), 2000);
  };

  // Listen for Escape key
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && mobileModalOpen) {
        setMobileModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileModalOpen]);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(phoneNetworkUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const modalContent = mobileModalOpen ? (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      {/* Backdrop Click Dismiss */}
      <div 
        className="absolute inset-0" 
        onClick={() => setMobileModalOpen(false)}
        aria-hidden="true"
      ></div>

      {/* Modal Dialog Card */}
      <div 
        role="dialog"
        aria-modal="true"
        className="relative z-10 bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200"
      >
        {/* Close Button */}
        <button
          onClick={() => setMobileModalOpen(false)}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-3 pr-10">
          <div className="w-11 h-11 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white">Access ScamLens on Any Device</h3>
            <p className="text-xs text-slate-400 mt-0.5">Works on any phone network (4G/5G, Wi-Fi), anywhere in the world</p>
          </div>
        </div>

        {/* Option 1: Live Public Internet Link (4G/5G/Any Network) with QR Code */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 flex flex-col sm:flex-row items-center gap-4">
          {mobileQrUrl && (
            <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 shrink-0 shadow-lg">
              <img src={mobileQrUrl} alt="Open on Phone QR" className="w-32 h-32 rounded-lg" />
            </div>
          )}
          <div className="space-y-2 text-xs text-center sm:text-left flex-1 min-w-0">
            <div className="flex items-center justify-center sm:justify-start space-x-1.5 text-emerald-400 font-bold">
              <Globe className="w-4 h-4" />
              <span>Public Worldwide Link (4G/5G & Any Network)</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Scan this QR with your phone camera or copy the live HTTPS link. Works from any mobile carrier or network!
            </p>
            <div className="flex items-center justify-between sm:justify-start space-x-2 pt-1 font-mono text-[11px] bg-slate-900/80 p-2 rounded-lg border border-slate-800">
              <span className="text-emerald-300 select-all truncate font-semibold">{publicWebUrl}</span>
              <button
                onClick={handleCopyPublicUrl}
                className="p-1.5 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 hover:text-white transition-colors shrink-0"
                title="Copy Public Link"
              >
                {copiedPublicUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Local Wi-Fi Option */}
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-850 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <Wifi className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-[11px]">Same Wi-Fi Network Link:</span>
            <span className="font-mono text-amber-300 text-[11px] select-all">{phoneNetworkUrl}</span>
          </div>
          <button
            onClick={handleCopyUrl}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Copy Wi-Fi URL"
          >
            {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Option 2: Download ZIP Archive */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Download className="w-4 h-4 text-rose-400" />
                <span>Download Project ZIP Archive</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Package: <strong>scamlens.zip (302 KB)</strong> • Complete source code & pre-built mobile app
              </p>
            </div>

            <a
              href="/scamlens.zip"
              download="scamlens.zip"
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 font-bold text-xs text-white shadow-lg flex items-center space-x-1.5 transition-all transform active:scale-95 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Download ZIP</span>
            </a>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80 text-[11px] text-slate-400 space-y-0.5">
            <span className="font-semibold text-slate-300 block">How to run on phone or PC:</span>
            <p>1. Unzip <code>scamlens.zip</code></p>
            <p>2. Run <code>npm install && npm run server</code></p>
            <p>3. Or open <code>dist/index.html</code> directly in any mobile browser</p>
          </div>
        </div>

        {/* Dismiss Button */}
        <div className="pt-1 flex justify-end">
          <button
            onClick={() => setMobileModalOpen(false)}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  ) : null;

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-18">
          
          {/* Logo & Tagline */}
          <div 
            className="flex items-center space-x-2.5 cursor-pointer select-none" 
            onClick={() => setActiveTab('scanner')}
          >
            <div className="relative">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-rose-500 via-red-600 to-amber-500 flex items-center justify-center shadow-md shadow-rose-950/40 ring-1 ring-rose-400/30">
                <ShieldAlert className="w-5 h-5 text-white" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-lg sm:text-xl font-extrabold tracking-tight text-white">
                  Scam<span className="text-rose-500">Lens</span>
                </span>
                <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
                  Pro Defense
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-400">
                NLP Highlighter • QR Verifier • OCR Image & Mail Radar • Call Shield
              </p>
            </div>
          </div>

          {/* Right Action Tools: Phone Access + Download ZIP + Frame Toggle + SOS 1930 */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            
            {/* Phone Access & Download ZIP Modal Trigger */}
            <button
              onClick={() => setMobileModalOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-indigo-600/25 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/40 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
              title="Open on phone or download ZIP"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Phone Access & ZIP</span>
            </button>

            {/* View Mode Toggle: Mobile Frame vs Wide Web */}
            <button
              onClick={() => setDeviceFrameMode(!deviceFrameMode)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-800 flex items-center space-x-1 transition-colors"
              title="Toggle Smartphone Mockup Frame View"
            >
              {deviceFrameMode ? (
                <>
                  <Monitor className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="hidden sm:inline">Wide View</span>
                </>
              ) : (
                <>
                  <Smartphone className="w-3.5 h-3.5 text-rose-400" />
                  <span className="hidden sm:inline">Phone Frame</span>
                </>
              )}
            </button>

            {/* Direct Dial 1930 */}
            <a
              href="tel:1930"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-red-950/50 ring-1 ring-red-400/40 transition-all transform active:scale-95"
              title="Call National Cybercrime Emergency Helpline 1930"
            >
              <PhoneCall className="w-3.5 h-3.5 text-white animate-bounce" />
              <span>SOS 1930</span>
            </a>

          </div>
        </div>

        {/* Desktop-only Tab Bar (Hidden on Mobile) */}
        <div className="hidden md:flex space-x-1 overflow-x-auto py-1.5 border-t border-slate-800/60 text-xs font-medium scrollbar-none">
          <button
            onClick={() => setActiveTab('scanner')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'scanner'
                ? 'bg-rose-500 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Message Scanner</span>
          </button>

          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'whatsapp'
                ? 'bg-emerald-600 text-white font-semibold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>WhatsApp Radar</span>
            <span className="text-[9px] px-1 rounded bg-emerald-950 text-emerald-300 font-bold border border-emerald-500/30">NEW</span>
          </button>

          <button
            onClick={() => setActiveTab('qr-shield')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'qr-shield'
                ? 'bg-rose-600 text-white font-semibold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5 text-rose-400" />
            <span>QR Verification</span>
            <span className="text-[9px] px-1 rounded bg-rose-950 text-rose-300 font-bold border border-rose-500/30">NEW</span>
          </button>

          <button
            onClick={() => setActiveTab('image-mail')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'image-mail'
                ? 'bg-indigo-600 text-white font-semibold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5 text-indigo-400" />
            <span>Image & Mail Radar</span>
            <span className="text-[9px] px-1 rounded bg-indigo-950 text-indigo-300 font-bold border border-indigo-500/30">NEW</span>
          </button>

          <button
            onClick={() => setActiveTab('call-guardian')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'call-guardian'
                ? 'bg-red-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PhoneCall className="w-3.5 h-3.5 text-red-400" />
            <span>Call Guardian & Red Signal</span>
          </button>

          <button
            onClick={() => setActiveTab('sandbox')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'sandbox'
                ? 'bg-amber-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>URL Sandbox</span>
          </button>

          <button
            onClick={() => setActiveTab('templates')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'templates'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Scam Vault</span>
          </button>

          <button
            onClick={() => setActiveTab('emergency')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all shrink-0 ${
              activeTab === 'emergency'
                ? 'bg-slate-800 text-rose-400 border border-rose-500/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>1930 / Chakshu Reporting</span>
          </button>
        </div>

      </div>

      {/* Render modal portal to document.body */}
      {typeof document !== 'undefined' && modalContent && createPortal(modalContent, document.body)}
    </header>
  );
}
