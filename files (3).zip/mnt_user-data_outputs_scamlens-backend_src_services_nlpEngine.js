import { THREAT_PATTERNS, extractUrlsFromText, extractPhonesFromText } from '../data/threatRules.js';
import { PSYCHOLOGICAL_TRICKS } from '../data/psychologyTricks.js';

export function analyzeMessageNLP(text) {
  if (!text || typeof text !== 'string') {
    return {
      segments: [{ type: 'text', text: '' }],
      highlights: [],
      threatScore: 0,
      threatLevel: 'No Content',
      categoryBreakdown: {},
      detectedUrls: [],
      detectedPhones: [],
      verdictSummary: 'No text provided for analysis.'
    };
  }

  const rawMatches = [];

  // 1. Gather all pattern matches
  THREAT_PATTERNS.forEach(rule => {
    // Reset regex index
    rule.regex.lastIndex = 0;
    let match;
    while ((match = rule.regex.exec(text)) !== null) {
      rawMatches.push({
        id: `hl-${match.index}-${match.index + match[0].length}`,
        start: match.index,
        end: match.index + match[0].length,
        text: match[0],
        category: rule.category,
        trickKey: rule.trickKey,
        severity: rule.severity,
        label: rule.label,
        trickData: PSYCHOLOGICAL_TRICKS[rule.trickKey] || null
      });
    }
  });

  // Sort matches by start position, then by length descending (to prefer longer matches)
  rawMatches.sort((a, b) => {
    if (a.start !== b.start) return a.start - b.start;
    return (b.end - b.start) - (a.end - a.start);
  });

  // 2. Remove overlapping spans
  const cleanMatches = [];
  let lastEnd = 0;

  for (const m of rawMatches) {
    if (m.start >= lastEnd) {
      cleanMatches.push(m);
      lastEnd = m.end;
    }
  }

  // 3. Construct text segments for interactive rendering
  const segments = [];
  let currentIndex = 0;

  cleanMatches.forEach(hl => {
    if (hl.start > currentIndex) {
      segments.push({
        type: 'text',
        text: text.slice(currentIndex, hl.start)
      });
    }
    segments.push({
      type: 'highlight',
      id: hl.id,
      text: text.slice(hl.start, hl.end),
      highlight: hl
    });
    currentIndex = hl.end;
  });

  if (currentIndex < text.length) {
    segments.push({
      type: 'text',
      text: text.slice(currentIndex)
    });
  }

  // 4. Extract URLs and Phones
  const detectedUrls = extractUrlsFromText(text);
  const detectedPhones = extractPhonesFromText(text);

  // 5. Category Breakdown
  const categoryBreakdown = {
    urgency: 0,
    fake_authority: 0,
    suspicious_link: 0,
    financial_trap: 0,
    fear_intimidation: 0,
    greed_bait: 0
  };

  cleanMatches.forEach(hl => {
    if (categoryBreakdown[hl.category] !== undefined) {
      categoryBreakdown[hl.category]++;
    }
  });

  // 6. Calculate Threat Score (0 - 100)
  let score = 0;
  score += categoryBreakdown.urgency * 18;
  score += categoryBreakdown.suspicious_link * 30;
  score += categoryBreakdown.fake_authority * 25;
  score += categoryBreakdown.financial_trap * 25;
  score += categoryBreakdown.fear_intimidation * 30;
  score += categoryBreakdown.greed_bait * 20;

  // Extra threat factors
  if (detectedUrls.some(u => u.includes('.apk') || u.includes('.top') || u.includes('.buzz') || u.includes('.cc'))) {
    score += 25;
  }
  if (detectedPhones.some(p => p.startsWith('+92') || p.startsWith('+234'))) {
    score += 35;
  }
  if (text.toLowerCase().includes('digital arrest')) {
    score += 40;
  }

  const finalScore = Math.min(100, Math.max(score > 0 ? 35 : 0, score));

  // Determine threat level & verdict
  let threatLevel = "Safe / Low Risk";
  let verdictSummary = "No overt manipulation signals detected. Always maintain healthy skepticism before sharing OTPs or personal credentials.";

  if (finalScore >= 80) {
    threatLevel = "CRITICAL PHISHING SCAM";
    verdictSummary = "Extremely dangerous scam! Multiple high-severity red flags detected including weaponized urgency, spoofed authority, and credential traps. Do NOT click any links, do NOT call numbers, and report immediately.";
  } else if (finalScore >= 55) {
    threatLevel = "HIGH RISK SCAM";
    verdictSummary = "Strong indications of social engineering. Urgency and unverified claims are being used to pressure you into hasty compliance.";
  } else if (finalScore >= 25) {
    threatLevel = "SUSPICIOUS CONTENT";
    verdictSummary = "Contains potential marketing pressure or unsolicited links. Verify with official sources before interacting.";
  }

  return {
    segments,
    highlights: cleanMatches,
    threatScore: finalScore,
    threatLevel,
    categoryBreakdown,
    detectedUrls,
    detectedPhones,
    verdictSummary
  };
}
