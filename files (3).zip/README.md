# ScamLens Frontend – Client-Side Application

The standalone frontend client for **ScamLens**, powered by **React 19**, **Vite**, and **TailwindCSS v4**.

It runs entirely client-side with:
- **Interactive Red-Flag Highlighter**: Multi-color cognitive trap tagging.
- **Multilingual Voice Engine**: Speech synthesis in 8 regional languages (English, Hindi, Hinglish, Tamil, Telugu, Kannada, Bengali, Marathi).
- **Interactive WhatsApp Studio**: Two-way chat simulator, screenshot attachment, and OCR.
- **Caller GPS & Identity Radar**: Geolocation coordinates and subscriber lookup.
- **Camera QR Scanner & UPI Guard**: Identifies reverse collect traps using `jsQR`.
- **Call Guardian HUD**: Mobile call simulator with flashing red alarm and siren audio.

---

## 🚀 Quick Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Run local development server (http://localhost:5173)
npm run dev

# 3. Build for production (outputs to ./dist)
npm run build

# 4. Preview production build locally
npm run preview
```

---

## 🌐 1-Click Deployment (Static / Serverless)

This frontend contains all necessary client-side threat engines and can be deployed directly to any static web host:

1. **Vercel**: Run `npx vercel` or import into [vercel.com/new](https://vercel.com/new). (Uses the included `vercel.json`).
2. **Netlify**: Drag & drop the `./dist` folder directly into [app.netlify.com/drop](https://app.netlify.com/drop).
3. **GitHub Pages**: Push this directory to a GitHub repo; the included `.github/workflows/deploy.yml` deploys automatically to `https://<username>.github.io/<repo>/`.
4. **Cloudflare Pages**: Connect to your GitHub repository at [pages.cloudflare.com](https://pages.cloudflare.com).
