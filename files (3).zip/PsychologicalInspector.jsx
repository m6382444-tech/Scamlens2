import React from 'react';
import { X, Brain, ShieldCheck, AlertTriangle, Lightbulb, ArrowRight, BookOpen } from 'lucide-react';
import { PSYCHOLOGICAL_TRICKS } from '../data/psychologyTricks';

export default function PsychologicalInspector({ highlight, onClose, allHighlights, onSelectHighlight }) {
  if (!highlight) return null;

  const trick = highlight.trickData || PSYCHOLOGICAL_TRICKS[highlight.trickKey] || PSYCHOLOGICAL_TRICKS.urgency;

  // Find next and previous highlight for easy navigation
  const currentIndex = allHighlights ? allHighlights.findIndex(h => h.id === highlight.id) : -1;
  const hasPrev = currentIndex > 0;
  const hasNext = allHighlights && currentIndex < allHighlights.length - 1;

  return (
    <div className="bg-slate-900 border border-slate-700/80 rounded-2xl p-5 sm:p-6 shadow-2xl relative transition-all animate-in fade-in slide-in-from-bottom-2">
      {/* Top Bar with Badge & Close */}
      <div className="flex items-start justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                {highlight.label}
              </span>
              <span className="text-xs font-semibold text-rose-400">
                Severity: {highlight.severity}
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-white mt-1">
              {trick.title}
            </h3>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Close Inspector"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Target Quotation */}
      <div className="my-4 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-sm text-rose-300 flex items-center space-x-2">
        <span className="text-xs font-sans text-slate-400 font-semibold uppercase tracking-wider">Trigger Text:</span>
        <span className="font-bold">"{highlight.text}"</span>
      </div>

      {/* Structured Psychological Deconstruction */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        
        {/* 1. Plain-English Explanation */}
        <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
          <div className="flex items-center space-x-2 text-amber-400 font-semibold">
            <Lightbulb className="w-4 h-4" />
            <h4>Plain-English Explanation</h4>
          </div>
          <p className="text-slate-300 leading-relaxed">
            {trick.description}
          </p>
        </div>

        {/* 2. Why Scammers Use It (Psychology) */}
        <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
          <div className="flex items-center space-x-2 text-rose-400 font-semibold">
            <AlertTriangle className="w-4 h-4" />
            <h4>Why Scammers Do This</h4>
          </div>
          <p className="text-slate-300 leading-relaxed">
            {trick.whyScammersUseIt}
          </p>
        </div>

        {/* 3. Legitimate Reality (How real agencies operate) */}
        <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
          <div className="flex items-center space-x-2 text-indigo-400 font-semibold">
            <BookOpen className="w-4 h-4" />
            <h4>How Real Institutions Act</h4>
          </div>
          <p className="text-slate-300 leading-relaxed">
            {trick.legitimateReality}
          </p>
        </div>

        {/* 4. Safe Action Protocol */}
        <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
          <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <h4>Safe Legitimate Alternative</h4>
          </div>
          <p className="text-emerald-200/90 leading-relaxed">
            {trick.safeAlternative}
          </p>
        </div>

      </div>

      {/* Navigation between highlights */}
      {allHighlights && allHighlights.length > 1 && (
        <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>
            Trigger {currentIndex + 1} of {allHighlights.length}
          </span>
          <div className="flex space-x-2">
            <button
              disabled={!hasPrev}
              onClick={() => onSelectHighlight(allHighlights[currentIndex - 1])}
              className={`px-3 py-1.5 rounded-lg border border-slate-700 font-medium transition-all ${
                hasPrev ? 'hover:bg-slate-800 text-slate-200' : 'opacity-40 cursor-not-allowed text-slate-500'
              }`}
            >
              Previous Trigger
            </button>
            <button
              disabled={!hasNext}
              onClick={() => onSelectHighlight(allHighlights[currentIndex + 1])}
              className={`px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 font-medium text-white transition-all flex items-center space-x-1 ${
                hasNext ? '' : 'opacity-40 cursor-not-allowed'
              }`}
            >
              <span>Next Trigger</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
