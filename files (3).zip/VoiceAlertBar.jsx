import React, { useState, useEffect } from 'react';
import { 
  Volume2, VolumeX, Globe, Sliders, Play, Square, Sparkles, CheckCircle2, AlertOctagon 
} from 'lucide-react';
import { 
  SUPPORTED_LANGUAGES, VOICE_TONES, speakVerdict, stopVoice, getVerdictScript 
} from '../services/voiceAlertService';

export default function VoiceAlertBar({ 
  isScam = true, 
  threatScore = 75,
  autoPlay = false,
  className = "" 
}) {
  const [selectedLang, setSelectedLang] = useState(() => localStorage.getItem('scamlens_lang') || 'en');
  const [selectedTone, setSelectedTone] = useState(() => localStorage.getItem('scamlens_tone') || 'pro');
  const [isPlaying, setIsPlaying] = useState(false);
  const [autoVoiceEnabled, setAutoVoiceEnabled] = useState(() => localStorage.getItem('scamlens_autovoice') === 'true');

  useEffect(() => {
    localStorage.setItem('scamlens_lang', selectedLang);
  }, [selectedLang]);

  useEffect(() => {
    localStorage.setItem('scamlens_tone', selectedTone);
  }, [selectedTone]);

  useEffect(() => {
    localStorage.setItem('scamlens_autovoice', autoVoiceEnabled ? 'true' : 'false');
  }, [autoVoiceEnabled]);

  // Handle auto-play on trigger if enabled
  useEffect(() => {
    if (autoPlay || autoVoiceEnabled) {
      handlePlay();
    }
    return () => stopVoice();
  }, [isScam, threatScore]);

  const handlePlay = () => {
    setIsPlaying(true);
    speakVerdict({
      isScam,
      language: selectedLang,
      tone: selectedTone,
      onStart: () => setIsPlaying(true),
      onEnd: () => setIsPlaying(false),
      onError: () => setIsPlaying(false)
    });
  };

  const handleStop = () => {
    stopVoice();
    setIsPlaying(false);
  };

  const currentScript = getVerdictScript(isScam, selectedLang, selectedTone);

  return (
    <div className={`p-3.5 sm:p-4 rounded-2xl border transition-all ${
      isScam 
        ? 'bg-gradient-to-r from-red-950/60 via-slate-900 to-rose-950/40 border-rose-500/40 shadow-lg shadow-rose-950/30' 
        : 'bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/40 border-emerald-500/40 shadow-lg shadow-emerald-950/30'
    } ${className}`}>
      
      {/* Top Row: Verdict Badge + Tone Switcher + Auto-voice Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        
        <div className="flex items-center space-x-2">
          {isScam ? (
            <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 text-xs font-black tracking-wide uppercase">
              <AlertOctagon className="w-3.5 h-3.5 animate-pulse" />
              <span>Voice Alert: Scam Verdict</span>
            </span>
          ) : (
            <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-black tracking-wide uppercase">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Voice Alert: Verified Safe</span>
            </span>
          )}
        </div>

        {/* Controls: Tone & Language */}
        <div className="flex items-center space-x-2 text-xs">
          {/* Tone Selector */}
          <div className="flex rounded-lg bg-slate-950 border border-slate-800 p-0.5">
            {VOICE_TONES.map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedTone(t.id)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-all ${
                  selectedTone === t.id 
                    ? (isScam ? 'bg-rose-600 text-white shadow' : 'bg-emerald-600 text-white shadow')
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={t.description}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Language Dropdown */}
          <div className="relative flex items-center">
            <Globe className="w-3.5 h-3.5 text-slate-400 absolute left-2 pointer-events-none" />
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="pl-7 pr-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-medium text-slate-200 hover:border-slate-700 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
            >
              {SUPPORTED_LANGUAGES.map(lang => (
                <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-200">
                  {lang.flag} {lang.name}
                </option>
              ))}
            </select>
          </div>
        </div>

      </div>

      {/* Center Row: Action Play Button + Live Spoken Transcript */}
      <div className="flex items-start gap-3">
        
        {/* Play/Stop Button with pulsating rings */}
        <button
          onClick={isPlaying ? handleStop : handlePlay}
          className={`relative shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center font-bold text-white shadow-xl transition-all transform active:scale-95 ${
            isPlaying
              ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-900/50'
              : isScam
                ? 'bg-gradient-to-br from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 shadow-rose-950/60'
                : 'bg-gradient-to-br from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-950/60'
          }`}
          title={isPlaying ? "Stop Voice Playback" : "Speak Voice Verdict"}
        >
          {isPlaying ? (
            <Square className="w-5 h-5 fill-current" />
          ) : (
            <Volume2 className="w-5 h-5 animate-bounce" />
          )}

          {isPlaying && (
            <span className="absolute -inset-1 rounded-xl border-2 border-white/60 animate-ping opacity-60"></span>
          )}
        </button>

        {/* Spoken Text Script Quote */}
        <div className="flex-1 min-w-0 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
            <span className="flex items-center space-x-1 font-semibold uppercase tracking-wider text-slate-300">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Voice Transcript ({SUPPORTED_LANGUAGES.find(l => l.code === selectedLang)?.name})</span>
            </span>
            {isPlaying && (
              <span className="text-emerald-400 font-mono animate-pulse flex items-center space-x-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                <span>Speaking...</span>
              </span>
            )}
          </div>
          <p className="text-xs sm:text-[13px] text-slate-200 font-medium leading-relaxed italic">
            "{currentScript}"
          </p>
        </div>

      </div>

      {/* Bottom subtle bar: Auto-voice toggle */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
        <label className="flex items-center space-x-2 cursor-pointer select-none hover:text-slate-200">
          <input
            type="checkbox"
            checked={autoVoiceEnabled}
            onChange={(e) => setAutoVoiceEnabled(e.target.checked)}
            className="rounded bg-slate-950 border-slate-700 text-rose-600 focus:ring-0 cursor-pointer"
          />
          <span>Auto-speak voice verdict whenever new text is scanned</span>
        </label>
        
        <span className="text-[10px] text-slate-500">
          Uses Web Speech & Audio Synthesizer
        </span>
      </div>

    </div>
  );
}
